import logo from './logo.svg';
import './App.css';
import ColorChanger from './components/colorBg';

function App() {
  return (
    <div className="App">
      <ColorChanger/>
    </div>
  );
}

export default App;
